package com.wwc.sg.dw.resources;

import com.wwc.sg.dw.representations.Workshop;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@Path("/workshop")
@Produces(MediaType.APPLICATION_JSON)
public class WorkshopResource {

    private static List<Workshop> workshops = new ArrayList<>();
    static{
        workshops.add(new Workshop("Coding with Java: Springboot", "Purnima"));
        workshops.add(new Workshop("Coding with Java: Dropwizard", "Marianne"));
        workshops.add(new Workshop("Test Driven Development", "Fay"));
    }

    public WorkshopResource() {
    }

    @GET
    public Response getWorkshops() {
        return Response.ok(workshops).build();
    }

    @GET
    @Path("/{id}")
    public Response getWorkshopById(@PathParam("id") int id) {
        Workshop workshop = workshops.get(id-1);
        if (workshop==null){
            return Response.ok("No workshop found.").build();
        } else {
            return Response.ok(workshop).build();
        }

    }
}