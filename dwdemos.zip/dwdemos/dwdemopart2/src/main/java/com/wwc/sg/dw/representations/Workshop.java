package com.wwc.sg.dw.representations;

import java.util.concurrent.atomic.AtomicInteger;

public class Workshop {

    private static AtomicInteger at = new AtomicInteger(0);

    private int id;
    private String name;
    private String host;

    public Workshop(String name, String host) {
        this.id = at.incrementAndGet();
        this.name = name;
        this.host = host;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }
}
